<div>
<div class="row sales layout-top-spacing">

    <div class="col-sm-12">
        <div class="widget widget-chart-one">
            <div class="widget-heading">
                <h4 class="card-title">
                <b><?php echo e($componentName); ?> | <?php echo e($pageTitle); ?></b>
                </h4>
                <ul class="tabs tab-pills">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Category_Create')): ?>
                    <li>
                        <a href="javascript:void(0)" class="tabmenu bg-dark" data-toggle="modal" data-target="#theModal">Agregar</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Category_Search')): ?>
            <?php echo $__env->make('common.searchbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="widget-content">
                <div class="table-responsive">
                    <table class="table table-bordered table striped mt-1">
                        <thead class="text-white" style="background: #3B3F5C">
                            <tr>
                                <th class="table-th text-white">DESCRIPCION</th>
                                <th class="table-th text-white text-center">IMAGEN</th>
                                <th class="table-th text-white text-center">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><h6><?php echo e($category->name); ?></h6></td>
                                <td class="text-center">
                                    <span>
                                        <img src="<?php echo e(asset('storage/categorias/' . $category->imagen)); ?>" 
                                        alt="imagen de ejemplo" height="70" width="80" class="rounded">
                                    </span>
                                </td>

                                <td class="text-center">
                                   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Category_Update')): ?>
                                    <a href="javascript:void(0)" 
                                    wire:click.prevent="Edit(<?php echo e($category->id); ?>)"
                                    class="btn btn-dark mtmobile" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                   
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Category_Destroy')): ?>
                                    <a href="javascript:void(0)"
                                    onclick="Confirm('<?php echo e($category->id); ?>',
                                    '<?php echo e($category->products->count()); ?>')" 
                                    class="btn btn-dark" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>

                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($categories->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('livewire.category.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function(){

        window.livewire.on('show-modal', msg =>{
            $('#theModal').modal('show');
        });

        window.livewire.on('category-added', msg =>{
            $('#theModal').modal('hide');
            noty(msg)
        });
        window.livewire.on('category-updated', msg =>{
            $('#theModal').modal('hide');
            noty(msg)
            });
        window.livewire.on('category-deleted', msg =>{
            noty(msg)
        });
        window.livewire.on('hide-modal', msg =>{
            $('#theModal').modal('hide');
            })
        
        window.livewire.on('hidden.bs.modal', msg =>{
            $('.er').modal('display', 'none');
        })
    });

    function Confirm(id, products)
    {
        if(products > 0){
            swal('NO SE PUEDE ELIMINAR LA CATEGORIA PORQUE TIENE PRODUCTOS RELACIONADOS')
            return;
        }
        
        swal({
        title: 'CONFIRMAR',
        text: 'CONFIRMAS ELIMINAR EL REGISTRO?',
        type: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cerrar',
        cancelButtonColor: '#fff',
        confirmButtonColor: '#3B3F5C',
        confirmButtonText: 'ACEPTAR',
        }).then(function(result){
            if(result.value){
            window.livewire.emit('deleteRow', id)
            swal.close()
        }
    })
    }
</script>
</div>
<?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/category/categories.blade.php ENDPATH**/ ?>