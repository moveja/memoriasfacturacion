<div>

<div wire:ignore.self class="modal fade" id="theModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h5 class="modal-title text-white">
            <b><?php echo e($componentName); ?></b> | <?php echo e($selected_id > 0 ? 'EDITAR' : 'CREAR'); ?>

        </h5>
        <h6 class="text-center text-warning" wire:loading>POR FAVOR ESPERE</h6>
      </div>
      <div class="modal-body">


      <div class="row">
      <div class="col-sm-12">
        <div class="input-group">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <span class="fas fa-edit">

                    </span>
                </span>
            </div>
            <input type="text" wire:model.lazy="roleName" class="form-control" placeholder="ej: Admin" maxlength="255">
        </div>
        <?php $__errorArgs = ['roleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      </div>


      </div>
      <div class="modal-footer">
        <button type="button" wire:click.prevent="resetUI()" 
        class="btn btn-dark close-btn text-info" data-dismiss="modal">CERRAR</button>
        
        <?php if($selected_id < 1): ?>
            <button type="button" wire:click.prevent="CreateRole()" 
            class="btn btn-dark close-modal">GUARDAR</button>

        <?php else: ?>        
            <button type="button" wire:click.prevent="UpdateRole()" 
            class="btn btn-dark close-modal">ACTUALIZAR</button>
        <?php endif; ?>
 
      </div>
    </div>
  </div>
</div>

</div><?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/roles/form.blade.php ENDPATH**/ ?>