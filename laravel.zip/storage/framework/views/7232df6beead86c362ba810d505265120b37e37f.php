<div>
<div wire:ignore.self class="modal fade" id="modalSearchProduct" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">

            <div class="input-group">
                <input type="text" wire:model="search" id="modal-search-input" placeholder="PUEDES BUSCAR POR EL NOMBRE DEL PRODUCTO, CODIGO" class="form-control search-form-control  ml-lg-auto">
                <div class="input-group-prepend">
                    <span class="input-group-text input-gp">
                        <i class="fas fa-search"></i>
                    </span>
                </div>
            </div>
            </div>
            <div class="modal-body">
                <div class="row p-2">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mt-1">
                            <thead class="text-white" style="background: #3B3F5C">
                                <tr>
                                    <th width="4%"></th>
                                    <th class="table-th text-left text-white">DESCRIPCION</th>
                                    <th width="13%" class="table-th text-center text-white">PRECIO</th>
                                    <th class="table-th text-center text-white">CATEGORIA</th>
                                    <th class="table-th text-center text-white">
                                        <button wire:click.prevent="addAll" class="btn btn-info" <?php echo e(count($products) > 0 ? '' : 'disabled'); ?>>
                                            <i class="fas fa-check"></i>
                                            TODOS
                                        </button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <span>
                                            <img src="<?php echo e(asset('storage/products/' . $product->imagen )); ?>" alt="img" height="50" width="50" class="rounded">
                                        </span>
                                    </td>
                                    <td>
                                        <div class="text-left">
                                            <h6><b><?php echo e($product->name); ?></b></h6>
                                            <small class="text-info"><?php echo e($product->barcode); ?></small>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <h6>$<?php echo e(number_format($product->price,2)); ?></h6>
                                    </td>
                                    <td class="text-center">
                                        <h6><?php echo e($product->category); ?></h6>
                                    </td>
                                    <td class="text-center">
                                        <button wire:click.prevent="$emit('scan-code-byid', <?php echo e($product->id); ?>)" class="btn btn-dark">
                                            <i class="fas fa-cart-arrow-down mr-1"></i>
                                            AGREGAR
                                        </button>                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan = "5">SIN RESULTADOS</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-dark" data-dismiss="modal">CERRAR VENTANA</button>
            </div>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/modalsearch/component.blade.php ENDPATH**/ ?>