<div>
<?php echo $__env->make('common.modalHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="row">
<div class="col-sm-12 col-md-6">
    <div class="form-group">
        <label>Tipo</label>
        <select wire:model="type" class = "form-control">
            <option value="Elegir">Elegir</option>
            <option value="Billete">Billete</option>
            <option value="Moneda">Moneda</option>
            <option value="Otro">Otro</option>
        </select>
        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-sm-12 col-md-6">
    <label>Value</label>
    <div class="input-group">
        <div class="input-group-prepend">
            <span class="input-group-text">
                <span class="fas fa-edit">

                </span>
            </span>
        </div>
        <input type="number" wire:model.lazy="value" class="form-control" placeholder="ej: 100.00">
    </div>
    <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="col-sm-12">
    <div class="form-group custom-file">
        <input type="file" class="custom-file-input form-control" wire:model="image" 
        accept="image/x-png, image/gif, image/jpg">
        <label class="custom-file-label" >Imagen <?php echo e($image); ?></label>
        <div><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger er"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
    </div>
</div>
</div>

<?php echo $__env->make('common.modalFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/denominations/form.blade.php ENDPATH**/ ?>