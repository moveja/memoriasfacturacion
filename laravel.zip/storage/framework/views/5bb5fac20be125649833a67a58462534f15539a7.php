<div>

<style></style>

<div class="row layout-top-spacing">

    <div class="col-sm-12 col-md-8">
        <!-- DETALLES -->
        <?php echo $__env->make('livewire.pos.partials.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="col-sm-12 col-md-4">
        <!--TOTAL-->
        <?php echo $__env->make('livewire.pos.partials.total', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--DENOMINATIONS <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-search', [])->html();
} elseif ($_instance->childHasBeenRendered('l587085728-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l587085728-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l587085728-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l587085728-0');
} else {
    $response = \Livewire\Livewire::mount('modal-search', []);
    $html = $response->html();
    $_instance->logRenderedChild('l587085728-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>-->
        <?php echo $__env->make('livewire.pos.partials.coins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-search', [])->html();
} elseif ($_instance->childHasBeenRendered('l587085728-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l587085728-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l587085728-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l587085728-1');
} else {
    $response = \Livewire\Livewire::mount('modal-search', []);
    $html = $response->html();
    $_instance->logRenderedChild('l587085728-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>

<script src="<?php echo e(asset('js/keypress.js')); ?>"></script>
<script src="<?php echo e(asset('js/onscan.js')); ?>"></script>

<?php echo $__env->make('livewire.pos.scripts.shortcuts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.pos.scripts.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.pos.scripts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.pos.scripts.scan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




</div>
<?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/pos/component.blade.php ENDPATH**/ ?>