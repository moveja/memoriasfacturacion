<div>

<div wire:ignore.self class="modal fade" id="modalDetails" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-dark">
        <h5 class="modal-title text-white">
            <b>Detalle de Venta # <?php echo e($saleId); ?></b>
        </h5>
        <h6 class="text-center text-warning" wire:loading>POR FAVOR ESPERE</h6>
      </div>
      <div class="modal-body">

      <div class="table-responsive">
                    <table class="table table-bordered table striped mt-1">
                        <thead class="text-white" style="background: #3B3F5C">
                            <tr>
                                <th class="table-th text-white text-center">FOLIO</th>
                                <th class="table-th text-white text-center">PRODUCTO</th>
                                <th class="table-th text-white text-center">PRECIO</th>
                                <th class="table-th text-white text-center">CANT</th>
                                <th class="table-th text-white text-center">IMPORTE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><h6><?php echo e($d->id); ?></h6></td>
                                <td><h6><?php echo e($d->product); ?></h6></td>
                                <td><h6><?php echo e(number_format($d->price,2)); ?></h6></td>
                                <td><h6><?php echo e(number_format($d->quantity,0)); ?></h6></td>
                                <td><h6><?php echo e(number_format($d->price * $d->quantity,2)); ?></h6></td>

                                

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3"><h5 class="text-center font-weight-bold">TOTALES</h5></td>
                                <td><h5 class="text-center"><?php echo e($countDetails); ?></h5></td>
                                <td><h5 class="text-center"><?php echo e(number_format($sumDetails,2)); ?></h5></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-dark close-btn text-info" data-dismiss="modal">CERRAR</button> 
      </div>
    </div>
  </div>
</div>

</div><?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/reports/sales-detail.blade.php ENDPATH**/ ?>