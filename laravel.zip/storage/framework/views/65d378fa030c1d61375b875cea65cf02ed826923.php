<div>
    <div class="row layout-top-spacing mt-4">

        <div class="col-sm-12 col-md-6">
            <div class="widget widget-chart one">
                <h4 class="p-3 text-center text-theme-1 font-bold">INSUMOS MÁS VENDIDOS</h4>
                <div id="chartTop5"></div>
            </div>
        </div>

        <div class="col-sm-12 col-md-6">
            <div class="widget widget-chart one">
                <h4 class="p-3 text-center text-theme-1 font-bold">VENTAS DE LA SEMANA</h4>
                <div id="areaChart"></div>
            </div>
        </div>

    </div>

    <div class="row pt-5">
    <div class="col-sm-12">
            <div class="widget widget-chart one">
                <h4 class="p-3 text-center text-theme-1 font-bold">VENTAS ANUALES <?php echo e($year); ?></h4>
                <div id="chartMonth"></div>
            </div>
        </div>
    </div>


    <?php echo $__env->make('livewire.dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>
<?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/dashboard/component.blade.php ENDPATH**/ ?>