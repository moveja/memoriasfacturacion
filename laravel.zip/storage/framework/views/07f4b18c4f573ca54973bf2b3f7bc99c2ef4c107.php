<div>


<div class="connect-sorting mb-2">
    <div class="btn-group">
        <button class="btn btn-dark mr-3" data-toggle="modal" data-target="#modalSearchProduct">
            <i class="fas fa-search"></i>
            BUSCAR PRODUCTO
        </button>

        <button wire:click="printLast" class="btn btn-dark mr-3">
            <i class="fas fa-search"></i>
            REIMPRIMIR ULTIMO F7
        </button>
    </div>
</div>


<div class="connect-sorting">
    <div class="connect-sorting-content">
        <div class="card simple-title-task ui-sortable-handle">
            <div class="card-body">
            <?php if($total > 0): ?>
            <div class="table-responsive tblscroll" style="max-height: 650px; overflow: hidden">
            <table class="table table-bordered table-striped mt-1">
                <thead class="text-white" style="background: #3B3F5C">
                    <tr>
                        <th width="10%"></th>
                        <th class="table-th text-left text-white">DESCRIPCION</th>
                        <th class="table-th text-center text-white">PRECIO</th>
                        <th width="13%" class="table-th text-center text-white">CANT</th>
                        <th class="table-th text-center text-white">IMPORTE</th>
                        <th class="table-th text-center text-white">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center table-th">
                            <?php if(count($item->attributes) > 0): ?>
                            <span>
                                <img src="<?php echo e(asset('storage/products/' . $item->attributes[0])); ?>" alt="imagen de producto" heigth="90" width="90" class="rounded">
                            </span>
                            <?php endif; ?>
                        </td>
                        <td><h6><?php echo e($item->name); ?></h6></td>
                        <td class="text-center">$<?php echo e(number_format($item->price,2)); ?></td>
                        <td>
                            <input type="number" id="r<?php echo e($item->id); ?>"
                            wire:change="updateQty(<?php echo e($item->id); ?>, $('#r' + <?php echo e($item->id); ?>).val() )"
                            style="font-size: 1rem!important"
                            class="form-control text-center"
                            value="<?php echo e($item->quantity); ?>">
                        </td>
                        <td class="text-center">
                            <h6>
                                $<?php echo e(number_format($item->price * $item->quantity,2)); ?>

                            </h6>
                        </td>
                        <td class="text-center">
                            dd.('<?php echo e($item->id); ?>');
                            <button onclick="Confirm('<?php echo e($item->id); ?>', 'removeItem', '¿CONFIRMAS ELIMINAR EL REGISTRO?')" 
                            class="btn btn-dark mbmobile">
                                <i class="fas fa-trash-alt"></i>
                            </button>

                            <button wire:click.prevent="decreaseQty(<?php echo e($item->id); ?>)" 
                            class="btn btn-dark mbmobile">
                                <i class="fas fa-minus"></i>
                            </button>

                            <button wire:click.prevent="increaseQty(<?php echo e($item->id); ?>)" 
                            class="btn btn-dark mbmobile">
                                <i class="fas fa-plus"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
            <?php else: ?>
                <h5 class="text-center text-muted">AGREGA PRODUCTOS A LA VENTA</h5>
            <?php endif; ?>

            <div wire:loading.inline wire:target="saveSale">
                <h4 class="text-danger text-center">GUARDANDO VENTA...</h4>
            </div>

            </div>
        </div>
    </div>
</div>


</div><?php /**PATH C:\laragon\www\memoriasclub\resources\views/livewire/pos/partials/detail.blade.php ENDPATH**/ ?>