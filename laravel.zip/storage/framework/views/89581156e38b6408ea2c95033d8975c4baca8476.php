<div class="header-container fixed-top">
        <header class="header navbar navbar-expand-sm">
            <ul class="navbar-item flex-row">
                <li class="nav-item theme-logo">
                    <a href="<?php echo e(url('home')); ?>">
                        <img src="assets/img/logo.png" class="navbar-logo" alt="logo">
                        <b style = "font-size: 30 px;">   MEMORIAS SUPPLY</b>
                    </a>
                </li>
            </ul> 

            <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg xmlns="http://www.w3.org/2000/svg" 
            width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" 
            stroke-linejoin="round" class="feather feather-list"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" 
            x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3" y2="6"></line><line 
            x1="3" y1="12" x2="3" y2="12"></line><line x1="3" y1="18" x2="3" y2="18"></line></svg></a>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search', [])->html();
} elseif ($_instance->childHasBeenRendered('hNlBQtn')) {
    $componentId = $_instance->getRenderedChildComponentId('hNlBQtn');
    $componentTag = $_instance->getRenderedChildComponentTagName('hNlBQtn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hNlBQtn');
} else {
    $response = \Livewire\Livewire::mount('search', []);
    $html = $response->html();
    $_instance->logRenderedChild('hNlBQtn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <ul class="navbar-item flex-row navbar-dropdown">
                

                <li class="nav-item dropdown user-profile-dropdown  order-lg-0 order-1">
                    <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user"></i>
                    </a>
                    <div class="dropdown-menu position-absolute animated fadeInUp" aria-labelledby="userProfileDropdown">
                        <div class="user-profile-section">
                            <div class="media mx-auto">
                                <img src="assets/img/perfil.png" class="img-fluid mr-2" alt="avatar">
                                <div class="media-body">
                                    <h5>Alvaro Muruchi</h5>
                                    <p>Administrador</p>
                                </div>
                            </div>
                        </div>
                        <div class="dropdown-item">
                            <a href="user_profile.html">
                            <i class="fas fa-user"></i>    
                            <span>Mi Perfil</span>
                            </a>
                        </div>
                        
                        <div class="dropdown-item">
                            <a href="<?php echo e(route('logout')); ?>" 
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit()">
                            
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" 
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" 
                                stroke-linejoin="round" class="feather feather-log-out"><path
                                 d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline 
                                 points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" 
                                 y2="12"></line></svg> <span>Salir</span>
                            </a>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </li>
            </ul>
        </header>
    </div><?php /**PATH C:\laragon\www\memoriasclub\resources\views/layouts/theme/header.blade.php ENDPATH**/ ?>